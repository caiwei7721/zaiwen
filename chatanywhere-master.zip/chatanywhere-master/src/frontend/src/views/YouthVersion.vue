<script setup lang='ts'>
import { ref } from 'vue';
defineProps<{ msg: string }>();

</script>
<template>
  <div>
    youth-version
  </div>
</template>
<style lang='scss' scoped></style>