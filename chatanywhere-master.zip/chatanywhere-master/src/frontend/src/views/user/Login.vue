<script setup lang='ts'>
import { ref } from 'vue';
defineProps<{ msg: string }>();

</script>
<template>
  <div>
    login
  </div>
</template>
<style lang='scss' scoped></style>