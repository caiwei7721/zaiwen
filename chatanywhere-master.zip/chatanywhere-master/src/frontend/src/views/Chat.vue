<script lang='ts' setup>
import Header from '@/components/Header.vue';

</script>
<template>
  <div class="root flex-c">
    <Header></Header>
    <div class="main">
      <router-view />
    </div>
  </div>
</template>
<style lang='scss' scoped>
.root {
  width: 100vw;
  height: 100vh;
  // overflow: hidden;
  background: var(--color-bg-2);
  color: var(--color-text-2);

  .main {
    flex: 1;
  }

}
</style>