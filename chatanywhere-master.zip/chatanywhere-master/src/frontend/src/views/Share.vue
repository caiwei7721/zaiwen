<script lang='ts' setup>
import { AessionInfo, RoleEnum } from '@/models/@types';
import { onMounted, ref } from 'vue';
import { appRef } from '@/models/app.ref';
import { FormatDate } from '@/utils/common.methods';
import { shareService } from '@/services/share.service';
import { useRoute } from 'vue-router';


const route = useRoute()
var records = ref<AessionInfo[]>([]);
const avatar = ref([appRef.user.data.avatar, appRef.user.ai.avatar])

onMounted(async () => {
  records.value = [{uid: '2ba61cc4b2beafe02', role: RoleEnum.AI, timestamp: 1687779756196, richtext: '请稍后,数据请求中......'}]
  var reco = await shareService.getrecords(route.params.uuid.toString())
  records.value = JSON.parse(reco).data;
  console.log(records)
})

</script>
<template>
  <div class="interactive flex-c">
    <div class="content flex-c" ref="sessionBox">
      <div class="sessions">
        <div class="item flex-c" v-for="item in records" :key="item.uid"
          :style="{ 'align-items': item.role === 'user' ? 'flex-end' : 'flex-start' }">
          <div class="top flex" v-if="item.role === 'user'">
            <icon-copy class="icon"/>
            <span class="date">{{ FormatDate(item.timestamp) }} </span>
            <img class="avatar" :src="avatar[0]" alt="">
          </div>
          <div class="top flex" v-else>
            <img class="avatar" :src="avatar[1]" alt="">
            <span class="date">{{ FormatDate(item.timestamp) }} </span>
            <icon-copy class="icon"/>
          </div>
          <Markdown class="richtext" v-if="item.role === 'user'" :source="item.richtext" previewTheme="cyanosis" />
          <Markdown class="richtext ai-richtext" v-else :source="item.richtext" :reverse="true" />
        </div>
      </div>
    </div>
  </div>
</template>
<style lang='scss' scoped>
.interactive {
  height: 100%;
  width: 100%;

  &>* {
    width: 100%;
  }

  .content {
    flex: 1;
    overflow-y: auto;
    margin-top: 10px;
    padding: 10px;
    scroll-behavior: smooth;
    justify-content: space-between;

    .sessions {
      width: 100%;
      flex: 1;

      .item {
        margin-bottom: 10px;
        width: 100%;

        .top {
          .date {
            margin: 0 10px;
            font-size: 12px;
            color: var(--color-neutral-6);
          }

          .icon {
            cursor: pointer;
            margin: 0 5px;
            font-size: 15px;
          }

          .avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
          }
        }

        .richtext {
          width: auto;
          max-width: calc(100% - 80px);
          margin: 5px 40px;
          border-radius: 3px;
          line-height: 23px;
          word-break: break-all;
          background: rgb(var(--green-3));
          color: var(--color-neutral-10);
          border-radius: 3px;
        }

        .ai-richtext {
          background: var(--color-neutral-10);
          color: var(--color-neutral-4);
        }
      }
    }




    .prompt {
      width: 100%;
      margin: 30px 0 5px;
      justify-content: space-between;
      align-items: flex-end;

      .left {
        .item {
          margin: 0;
          margin-right: 5px;

          &:last-child {
            margin: 0;
          }
        }
      }

      .right {
        max-width: 50%;
        overflow: hidden;
        align-items: flex-end;

        .item {
          width: fit-content;
          max-width: 100%;
          border-radius: 20px 20px 0 20px;
          height: 37px;
          margin-bottom: 10px;
          cursor: pointer;
        }
      }

      @media screen and (max-width: 1200px) {
        flex-direction: column;

        .right {
          width: inherit;
          max-width: max-content;
          flex-direction: revert;
          overflow-x: auto;
          margin-top: 10px;

          .item {
            max-width: max-content;
            height: 30px;
            margin-right: 10px;
            border-radius: 5px;
            font-size: .9rem;
          }
        }
      }
    }
  }

  .bottom {
    position: relative;
    align-items: flex-end;
    padding-bottom: 17px;

    .send {
      position: absolute;
      right: 10px;
      bottom: 27px;
      // margin-left: 10px;
    }

    @media screen and (max-width: 1200px) {
      padding-bottom: 0;

      .send {
        position: absolute;
        right: 10px;
        bottom: 10px;
      }
    }
  }
}
</style>