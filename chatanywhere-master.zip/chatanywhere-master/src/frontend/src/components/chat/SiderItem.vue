<script setup lang='ts'>
import { SiderMenuInfo, SiderMenuEnum } from '@/models/@types';
defineProps<{ item: SiderMenuInfo, removeDesc: string, isCurr: boolean }>();
const emits = defineEmits(['clickItem', 'edit', 'remove']);

</script>
<template>
  <div class="menu flex" :class="{ 'menu-activity': isCurr }"
    @click.stop="() => item.type === SiderMenuEnum.Group ? null : emits('clickItem')">
    <div class="left ellipsis">
      <icon-file size="17" /> {{ item.label }}
    </div>
    <div class="right">
      <icon-edit @click.stop="emits('edit')" />
      <a-popconfirm :content="removeDesc" type="error" @ok="emits('remove')">
        <icon-delete @click.stop="null" />
      </a-popconfirm>
    </div>
  </div>
</template>
<style lang='scss' scoped>
.menu {
  margin: 20px 20px;
  position: relative;
  height: 100%;
  color: var(--color-neutral-8);
  padding: 15px 15px;
  border-radius: 7px;
  cursor: pointer;
  justify-content: space-between;
  border: 1px solid #00000000;
  box-shadow: 0 0 10px var(--color-border-3);

  @media screen and (min-width: 1200px) {
    &:hover {
      // background: var(--color-neutral-3); 
      box-shadow: 0 0 10px var(--color-border-4);
      transform: translateY(-1px);
      animation: all 1s;
    }
  }


}

.menu-activity {
  border: 1px solid rgb(var(--arcoblue-5));
  box-shadow: 0 0 10px var(--color-border-4);
  color: rgb(var(--arcoblue-5));
}


.right {
  min-width: 35px;

  &>* {
    margin-right: 5px;

    &:last-child {
      margin: 0;
    }
  }
}
</style>