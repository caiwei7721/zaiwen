<script lang='ts' setup>
import illustrate from "@/assets/md/illustrate.md?raw"
import Markdown from './Markdown.vue';



</script>
<template>
  <div class="explanation">
    <Markdown :source="illustrate" />
  </div>
</template>
<style lang='scss' scoped>
.explanation {
  width: 100%;
  height: 100%;
  overflow: auto;
  padding: 40px;
}
</style>