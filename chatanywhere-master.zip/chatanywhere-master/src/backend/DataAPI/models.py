from core import setting, mgClient

dbList = mgClient.list_database_names()
for dbName in ["chat"]:
    if(dbName not in dbList):
        db = mgClient[dbName]
        print(f"数据库已创建:{dbName}")